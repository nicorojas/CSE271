// Nico Rojas
// CSE 271, Lab 5
// 2.26.16

public class PersonTester {

	public static void main(String[] args) {

		// Person Tester
		Person rapper = new Person("Drake", 1994);
		Student freshman = new Student("Nico", 1997, "Computer Science");
		Instructor professor = new Instructor("Jim", 1972, 110000);
		System.out.println(rapper);
		System.out.println(freshman);
		System.out.println(professor);
	}
}
